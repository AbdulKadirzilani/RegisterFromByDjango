from django import forms
from .models import Qost

class QostForm(forms.ModelForm):
    class Meta :
        model= Qost

        fields = [
            "title",
            "content",
            "image",

        ]