from django.contrib import admin
from Qosts.models import Qost



class QostModelAdmin(admin.ModelAdmin):
    list_display = ['title','createdat','update']
    list_display_links=['title' ]
    search_fields =['title' ]

    class Meta :
        model = Qost




admin.site.register(Qost,QostModelAdmin)