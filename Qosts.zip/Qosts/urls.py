from django.urls import path

from . import views

from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
   # path('', views.home, name='index'),
    path('details/<int:pid>/', views.details, name='detailsN'),



    path('', views.post_home, name='post_home'),

    path('create/', views.CreatePost, name='CreatePost'),
    path('update/<id>/', views.UpdatePost, name='UpdatePost'),
    path('delete/<pid>/', views.DeletePost, name='DeletePost'),

    path('li/', views.showall, name='ListAll'),
    path('number/', views.number, name='number'),

]

if settings.DEBUG:
    urlpatterns + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

