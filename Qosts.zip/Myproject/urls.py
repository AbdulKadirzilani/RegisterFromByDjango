

from django.contrib import admin
from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static
#from . import blogapp


urlpatterns = [
    #path('fisrtapp/', include('fisrtapp.urls')),
    path('admin/', admin.site.urls),
    path('fisrtapp/', include('fisrtapp.urls')),

    path('blogapp/', include('blogapp.urls')),

    path('user/', include('user_info.urls'), name='user'),

    path('NewLogin/', include('NewLogin.urls'), name='newlogin'),



    path('mbstu/', include('mbstu.urls'),name ='mbstu'),
    path('account/', include('account.urls'),name ='account'),
    path('student_info/', include('student_info.urls'),name ='studentapp'),

    path('info/', include('information.urls'), name='information_bangladesh'),

    path('Qosts/', include('Qosts.urls')),

]


if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    
