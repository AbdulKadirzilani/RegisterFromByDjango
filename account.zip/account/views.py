#from django.shortcuts import render,redirect
#from django.http import HttpResponse, HttpResponseRedirect
#from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.forms import UserCreationForm
#from django.contrib.auth.forms import registerUser
from django.shortcuts import render,HttpResponse, Http404, get_object_or_404, redirect
#from .models import author, category, article, comment
from django.contrib.auth import authenticate, login, logout
#rom django.contrib.auth.models import User
#from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
#from django.db.models import Q
#from .forms import createForm, registerUser, createAuthor, categoryForm, commentForm
#from .models import category, article, comment
from django.contrib import messages
from django.views import View
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.conf import settings
from django.core.mail import send_mail
from .token import activation_token
from .models import registerUser



def user_login(request):

  if request.user.is_authenticated:
        return render(request, 'thankyou.html')
  else:
    if request.method == 'POST':
        username = request.POST.get('users')
        password = request.POST.get('pass')
        user2 = authenticate(request, username=username, password=password)
        if user2:
        #user is not None:
            login(request, user2) #user2 ta sucessful hole login korbo
            return render(request, 'thankyou.html') #login hole ekta page e niya jabe
        else:
            return HttpResponse("Username or password incorrect")
    return render(request, 'log1/login.html')

def user_logout(request):
    logout(request)
    return redirect('login')
    #return render(request, 'log1/thankyou2.html')
    #return HttpResponseRedirect(login.get_absolute_url())


def getRegister(request):
    form = registerUser(request.POST or None)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.is_active = False
        instance.save()
        site=get_current_site(request)
        mail_subject="Confirmation message for blog"
        message=render_to_string('confirm_email.html',{
            "user":instance,
            'domain':site.domain,
            'uid':instance.id,
            'token':activation_token.make_token(instance)
        })
        to_email=form.cleaned_data.get('email')
        to_list=[to_email]
        from_email=settings.EMAIL_HOST_USER
        send_mail(mail_subject, message, from_email, to_list, fail_silently=True)
        return HttpResponse("<h1>Thanks for your registration. A confirmation link was sent to your email</h1>")
    return render(request, 'register.html', {"form": form})

'''
def getCategory(request):
    query = category.objects.all()
    return render(request, 'topics.html', {"topic": query})


def createTopic(request):
    if request.user.is_authenticated:
        if request.user.is_staff or request.user.is_superuser:
            form = categoryForm(request.POST or None)
            if form.is_valid():
                instance = form.save(commit=False)
                instance.save()
                messages.success(request, 'topic is created!')
                return redirect('blog:category')
            return render(request, 'create_topics.html', {"form": form})
        else:
            raise Http404('You are not authorized to access this page')
    else:
        return redirect('blog:login')
'''


def activate(reuest):
    return render_to_string()





'''
def getlogin(request):
    if request.method == 'POST':
        username = request.POST.get('user')
        password = request.POST.get('pass')
        user = authenticate(username=username, password=password)
    if user:
        login(request, user)
        return render(request, 'thankyou.html')
        #return HttpResponse("Username or password incorrect")
    return render(request, 'log1/login.html')

'''











'''
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/login')
'''