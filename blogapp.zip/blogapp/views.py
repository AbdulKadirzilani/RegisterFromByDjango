'''
from django.shortcuts import render

#from django.shortcuts import render,HttpResponse


def index(request):
 	return render(request, 'account2/login2.html',{'name':'harun Ur Rashid','district':'kushtia'})
'''



'''


from django.shortcuts import render
from .models import Post

def post_list(request):
    post_list = Post.objects.all()
    return render(request, 'account3/post-list.html', {'post_list': post_list})
'''



from django.shortcuts import render,HttpResponse

#from django.shortcuts import render
from .models import Post
'''
def index(request):
    all_post = Post.objects.all()
    return render(request, 'account2/login2.html',{'all_post_list': all_post})

'''


def post_list(request):
    post_list = Post.objects.all()
    return render(request, 'account3/post_list.html', {'post_list': post_list})




def single_post(request, post_id):
    post = Post.objects.get(pk=post_id)
    print(post)
    return render(request, 'account9/single_post.html', {'post':post})



def cas(request):
    return render(request, 'guido/van.html')



x="This is our sent data\n"
y="\n Duido van Rossen"

def index(request):
    return HttpResponse("Hello, we can try work hard."+x+y)
'''
def single_post(request):
   post = Post.objects.get(pk=1)
   print(post)
   return render(request, 'account9/single_post.html',{'post':post})
'''

