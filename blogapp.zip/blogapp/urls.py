from django.urls import path
from . import views
#from blogapp.views import blogapp

urlpatterns = [
    path('index/', views.index, name='index'),
    #path('', views.post_list, name='post-list'),
    path('vk/',views.cas, name='vk'),


    path('post-list/', views.post_list, name='post-list'),

    path('single-post/<post_id>/', views.single_post, name='singleppost')

    #path('single-post/(?P<post_id>[0-9]+)/', views.single_post, name='single-post')


]