from django.contrib import admin
from .models import Post
admin.site.register(Post)























'''
from .models import photo

class photo_Admin(admin.ModelAdmin):
    list_display = ['title','upload_time']
    class Meta:
        model = photo

admin.site.register(photo,photo_Admin)
'''
# Register your models here.
